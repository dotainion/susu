<?php
namespace src\infrastructure\exeptions;

use Exception;

class NoResultsException extends Exception{

}