<?php
namespace src\infrastructure\exeptions;

use Exception;

class UrlNotFoundException extends Exception{

}