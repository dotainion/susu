<?php
namespace src\infrastructure;

interface IObjects{
    public function id():IId;
}