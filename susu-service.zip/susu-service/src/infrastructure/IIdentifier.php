<?php
namespace src\infrastructure;

interface IIdentifier{

    public function toString():string;
}