<?php
namespace src\module\susu\service;

use src\infrastructure\Assert;
use src\infrastructure\Collector;
use src\infrastructure\DateHelper;
use src\infrastructure\Id;
use src\infrastructure\Service;
use src\module\susu\logic\CalculateSchedule;
use src\module\susu\logic\FetchSusu;
use src\module\susu\logic\ListSusuLink;
use src\module\susu\objects\Susu;
use src\module\susu\objects\SusuLink;
use src\module\user\logic\ListUsers;

class ListScheduleService extends Service{
    protected FetchSusu $susu;
    protected ListSusuLink $links;
    protected ListUsers $users;

    public function __construct(){
        parent::__construct(false);
        $this->susu = new FetchSusu();
        $this->links = new ListSusuLink();
        $this->users = new ListUsers();
    }
    
    public function process($groupId){
        //Assert::validUuid($groupId, 'Group not found.');

        //$collector = $this->susu->activeByGroupId(new Id($groupId));
        //$collector->assertHasItem('Susu not yet stared.');
        $susu = new Susu();// $collector->first();

        //for testing..
        $susu->setId((new Id())->new()->toString());
        $susu->setContribution('2544');
        $susu->setCycle('Weekly');
        $susu->setPayoutDate((new DateHelper())->new()->toString());
        $susu->setStartDate((new DateHelper())->new()->toString());
        $susu->setGroupId((new Id())->new()->toString());
        $susu->setPendingStart(true);
        $susu->setCompleted(false);
    

        //$links = $this->links->links(new Id($groupId));
        //$userIdArray = array_map(fn($us) => $us->memberId(), $links->list());
        $users = $this->users->users();//usersByIdArray($userIdArray);

        //for testing
        $links = new Collector();
        foreach($users->list() as $i => $user){
            $link = new SusuLink();
            $link->setGroupId($susu->groupId()->toString());
            $link->setMemberId($user->id()->toString());
            $link->setPosition($i+1);
            $links->add($link);
        }

        $schedule = new CalculateSchedule($susu, $users, $links);
        
        $this->setOutput($schedule->schedules());
        return $this;
    }
}